﻿using CarvedRock.DataAccess.Models;

var _dbContext = new CarvedRockContext();

Console.WriteLine("Press any key to exit");
Console.Read();

